<?php
// ----------------- CONFIG & SETUP -----------------
date_default_timezone_set('Africa/Kampala');
$config = require __DIR__ . '/config.php';
$statusFile = __DIR__ . '/status.json';

// Ensure status file exists
if (!file_exists($statusFile)) {
    file_put_contents($statusFile, json_encode([]));
}

// Load previous status
$previousStatus = json_decode(file_get_contents($statusFile), true);
$currentStatus  = [];
$now = time();

// ----------------- HELPERS -----------------
function checkServer($host, $port, $timeout) {
    $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
    if ($fp) { fclose($fp); return true; }
    return false;
}

// SMTP Alert using PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require __DIR__ . '/vendor/autoload.php';

function sendAlert($to, $from, $subject, $message) {
    global $config;
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = $config['smtp']['host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $config['smtp']['username'];
        $mail->Password   = $config['smtp']['password'];
        $mail->SMTPSecure = $config['smtp']['secure'];
        $mail->Port       = $config['smtp']['port'];

        $mail->setFrom($from, $config['company_name']);
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->Body    = $message;

        $mail->send();
    } catch (Exception $e) {
        error_log("SMTP Mail Error: {$mail->ErrorInfo}");
    }
}

function duration($seconds) {
    $h = floor($seconds / 3600);
    $m = floor(($seconds % 3600) / 60);
    return sprintf('%02dh %02dm', $h, $m);
}

// ----------------- SERVER CHECK -----------------
foreach ($config['servers'] as $server) {
    $key = md5($server['host'] . $server['port']);
    $isUp = checkServer($server['host'], $server['port'], $config['check_timeout']);

    $prev = $previousStatus[$key] ?? [
        'status' => 'unknown',
        'since' => $now,
        'alert_sent' => false,
        'history' => []
    ];
    $history = $prev['history'] ?? [];

    if ($isUp) {
        // Recovering from down
        if ($prev['status'] === 'down') {
            $history[] = ['status'=>'recovered','timestamp'=>$now];
        }
        $currentStatus[$key] = [
            'name' => $server['name'],
            'status' => 'up',
            'since' => ($prev['status']==='up') ? $prev['since'] : $now,
            'alert_sent' => false,
            'history' => $history
        ];
    } else {
        // Server down
        $downSince = ($prev['status']==='down') ? $prev['since'] : $now;
        if ($prev['status']!=='down') {
            $history[] = ['status'=>'down','timestamp'=>$now];
        }

        $downtime = $now - $downSince;
        $alertSent = $prev['alert_sent'];
        if ($downtime >= $config['alert_after'] && !$alertSent) {
            sendAlert(
                $config['alert_email'],
                $config['email_from'],
                "🚨 Server DOWN: {$server['name']}",
                "{$server['name']} ({$server['host']}:{$server['port']}) has been DOWN for more than "
                . ($config['alert_after']/60) . " minutes."
            );
            $alertSent = true;
        }

        $currentStatus[$key] = [
            'name' => $server['name'],
            'status' => 'down',
            'since' => $downSince,
            'alert_sent' => $alertSent,
            'history' => $history
        ];
    }
}

// Save current status to file
file_put_contents($statusFile, json_encode($currentStatus, JSON_PRETTY_PRINT));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $config['company_name']; ?> – Service Health</title>
<style>
:root {
    --bg:#f5f7fa; --card:#fff; --border:#e5e7eb;
    --text:#1f2937; --muted:#6b7280;
    --green:#107c10; --red:#d13438;
}
body{margin:0;font-family:"Segoe UI",system-ui;background:var(--bg);color:var(--text);}
.container{max-width:1200px;margin:auto;padding:32px;}
.header h1{font-size:28px;margin:0;}
.header p{margin-top:6px;font-size:14px;color:var(--muted);}
.global{margin:25px 0;padding:18px 22px;background:var(--card);border:1px solid var(--border);border-left:6px solid var(--green);border-radius:6px;font-weight:600;}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:20px;}
.card{background:var(--card);border:1px solid var(--border);border-radius:6px;padding:18px;}
.card-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;}
.card-header h2{font-size:18px;margin:0;}
.badge{font-size:13px;padding:4px 12px;border-radius:20px;font-weight:600;}
.ok{background:#e6f2e6;color:var(--green);}
.bad{background:#fde7e9;color:var(--red);}
.service{display:flex;justify-content:space-between;padding:10px 0;border-top:1px solid var(--border);font-size:14px;}
.service:first-child{border-top:none;}
.history{font-size:12px;color:var(--muted);margin-top:6px;}
.footer{margin-top:50px;text-align:center;font-size:13px;color:var(--muted);}
</style>
</head>
<body>
<div class="container">
<div class="header">
    <h1>Service Health Status</h1>
    <p id="last-refreshed">Last refreshed: <?= date('H:i:s'); ?></p>
</div>

<div class="grid" id="server-grid">
<?php foreach ($currentStatus as $srv): ?>
<div class="card">
    <div class="card-header">
        <h2><?= htmlspecialchars($srv['name']); ?></h2>
        <span class="badge <?= $srv['status']==='up'?'ok':'bad' ?>">
            <?= strtoupper($srv['status']); ?>
        </span>
    </div>
    <div class="service">
        <span>Uptime / Downtime:</span>
        <span><?= duration(time()-$srv['since']); ?></span>
    </div>
    <?php if(!empty($srv['history'])): ?>
    <div class="history">
        <strong>Incident History:</strong><br>
        <?php foreach(array_reverse($srv['history']) as $h): ?>
            <?= ucfirst($h['status']); ?> at <?= date('Y-m-d H:i:s',$h['timestamp']); ?><br>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php endforeach; ?>
</div>

<div class="footer">
    © <?= date('Y'); ?> <?= $config['company_name']; ?>
</div>
</div>

<script>
function duration(seconds){
    let h=Math.floor(seconds/3600), m=Math.floor((seconds%3600)/60);
    return `${h.toString().padStart(2,'0')}h ${m.toString().padStart(2,'0')}m`;
}

function fetchStatus(){
    fetch('status_api.php',{cache:"no-store"})
    .then(res=>res.json())
    .then(data=>{
        document.getElementById("last-refreshed").textContent = "Last refreshed: "+data.timestamp;
        const grid=document.getElementById("server-grid");
        grid.innerHTML="";
        Object.values(data.servers).forEach(srv=>{
            const card=document.createElement("div"); card.className="card";
            let badgeClass=srv.status==="up"?"ok":"bad";
            let uptime=duration(Math.floor(Date.now()/1000-srv.since));
            let historyHtml="";
            if(srv.history&&srv.history.length>0){
                historyHtml=`<div class="history"><strong>Incident History:</strong><br>`;
                srv.history.slice().reverse().forEach(h=>{
                    let ts=new Date(h.timestamp*1000).toLocaleString();
                    historyHtml+=`${h.status.charAt(0).toUpperCase()+h.status.slice(1)} at ${ts}<br>`;
                });
                historyHtml+="</div>";
            }
            card.innerHTML=`
                <div class="card-header">
                    <h2>${srv.name}</h2>
                    <span class="badge ${badgeClass}">${srv.status.toUpperCase()}</span>
                </div>
                <div class="service">
                    <span>Uptime / Downtime:</span>
                    <span>${uptime}</span>
                </div>
                ${historyHtml}
            `;
            grid.appendChild(card);
        });
    })
    .catch(err=>console.error("Failed to fetch status:",err));
}

// Initial fetch
fetchStatus();
// Auto-refresh every 60s
setInterval(fetchStatus,60000);
</script>
</body>
</html>
