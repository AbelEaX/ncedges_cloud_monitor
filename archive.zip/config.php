<?php
return [
    'company_name' => 'Nova Cloud Hosting',
    'alert_email'  => 'webadmin@ncedges.com',   // recipient
    'email_from'   => 'webadmin@ncedges.com',   // sender
    'check_timeout'=> 3,
    'alert_after'  => 300,
    'timezone'     => 'Africa/Kampala',
    // SMTP Settings
    'smtp' => [
        'host'     => 'mail-gw.ncedges.com',   // your SMTP server
        'port'     => 465,                   // usually 587 or 465
        'username' => 'webadmin@ncedges.com',
        'password' => 'User@2026@',
        'secure'   => 'ssl'                  // or 'ssl'
    ],

    'servers' => [
        [
            'name' => 'Web Server 1',
            'host' => '10.10.1.2',
            'port' => 443
        ],
        [
            'name' => 'Nova Mail Server',
            'host' => '10.10.1.3',
            'port' => 6071
        ],
        [
            'name' => 'Nova Billing System',
        [
            'name' => 'London Backup ',
            'host' => 'public-1.ncedges.com',
            'port' => 443
            ],    'host' => '10.10.1.4',
            'port' => 5067
        ],
        [
            'name' => 'Document Server',
            'host' => 'cloud.ncedges.com',
            'port' => 443
            ],
        [
            'name' => 'Voice Mail Gateway',
            'host' => '10.10.1.7',
            'port' => 8090
            ],
        [
            'name' => 'Unifi Controller ',
            'host' => '10.10.1.7',
            'port' => 8443
            ],

    ]
];
